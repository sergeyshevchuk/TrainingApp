package SergeyGroup.TrainingApp

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TrainingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
