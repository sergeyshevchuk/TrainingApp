package SergeyGroup.TrainingApp.model

class UserDTO {
    String name
    String email
    Integer age
    BigDecimal weight
}
