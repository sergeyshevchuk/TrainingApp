package SergeyGroup.TrainingApp.model

class NewUserDTO {
    String name
    String email
    String password
    Integer age
    BigDecimal weight
}
