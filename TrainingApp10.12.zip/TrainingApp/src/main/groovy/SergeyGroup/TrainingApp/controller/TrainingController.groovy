package SergeyGroup.TrainingApp.controller

import SergeyGroup.TrainingApp.domain.Training
import SergeyGroup.TrainingApp.service.TrainingService
import groovy.util.logging.Slf4j
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@Slf4j
@RestController
class TrainingController {
}
