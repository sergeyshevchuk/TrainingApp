package SergeyGroup.TrainingApp

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class TrainingAppApplication {

	static void main(String[] args) {
		SpringApplication.run(TrainingAppApplication, args)
	}

}
